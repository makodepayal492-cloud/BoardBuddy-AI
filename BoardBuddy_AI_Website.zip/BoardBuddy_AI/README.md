# BoardBuddy AI

A responsive standalone prototype for an AI board-exam quiz generator.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. No build step or installation is required.

## Included in this prototype
- Dashboard with real local quiz history and analytics
- Quiz generator with built-in sample question bank
- Answer selection, navigation, timer, scoring, and answer explanations
- Mistake Memory saved in browser local storage
- Targeted weak-topic practice
- Study coach tasks
- Exam mode
- Notes input and TXT file reading
- Guided demo tutor
- Profile preferences and JSON data export

## Important limitations
This is a standalone front-end demo. It does not include a live LLM API, cloud database, login system, or PDF text extraction. The interface clearly labels demo-mode features. To make it production-ready, connect a secure backend/edge function to an AI provider, add a database such as Supabase with row-level security, and implement PDF extraction/OCR where needed. Never expose secret API keys in frontend code.

## Demo walkthrough
1. Open Generate Quiz.
2. Choose Mathematics → Quadratic Equations.
3. Take the quiz and deliberately answer one or two questions incorrectly.
4. Submit and review explanations.
5. Open Mistake Memory and see saved errors.
6. Choose Practice weak topics and compare the next attempt.
7. Open Analytics and Study Coach to show saved progress.
